import static org.junit.jupiter.api.Assertions.*;

class CheckInTest {

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
    }

    @org.junit.jupiter.api.Test
    void checkIn() {
    }
}