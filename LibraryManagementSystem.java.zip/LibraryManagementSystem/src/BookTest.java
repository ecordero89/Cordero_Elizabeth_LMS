import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/*Elizabeth Cordero
 *Software Development I
 *CEN3024C-24667
 * 03/10/2024
 */


class BookTest {

    //Create an object to be tested
    private Book book;

    @BeforeEach
    void setUp() {
        //Supply test data
        book = new Book(1, "Title", "Author");
    }
    @Test
    void testCheckOut() {
        book.checkOut();
        assertTrue(book.isCheckedOut());
        assertNotNull(book.getDueDate());
    }

    @Test
    void testCheckIn() {
        book.checkOut();
        assertTrue(book.isCheckedOut());
        book.checkIn();
        assertFalse(book.isCheckedOut());
        assertNull(book.getDueDate());
    }

}
