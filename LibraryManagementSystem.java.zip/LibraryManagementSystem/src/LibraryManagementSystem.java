import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Iterator;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
import javax.swing.SwingUtilities;


/**
 * This class represents a Book with id, title, author, and checkout status
 */

class Book {
    private int id;
    private String title;
    private String author;
    private boolean checkedOut;
    private LocalDate dueDate;


    /**
     * Constructor to initialize a Book object with ID, title, and author
     * @param id The ID of the book
     * @param title The title of the book
     * @param author The author of the book
     */

     public Book(int id, String title, String author) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.checkedOut = false;
        this.dueDate = null;
    }

    /**
    Gets the due date of the book
    *
    *@return The due date of the book
     */
    public LocalDate getDueDate() {
        return dueDate;
    }

    /** Getter method to retrieve the ID pf the book
    *
    * @return The ID of the book
     */
    public int getId() {
        return id;
    }

    /** Gets the title of the book
    *
    * @return The title of the book
     */
    public String getTitle() {
        return title;
    }

    /** Gets the author of the book
    *
    * @return The author of the book
     */
    public String getAuthor() {
        return author;
    }

    /** Checks if the book is checked out
    *
    * @return true if the book is checked out, false if not
     */

    public boolean isCheckedOut() {
        return checkedOut;
    }

    /**
    * Checks out the book
     */

    public void checkOut(){

        checkedOut = true;
        dueDate =LocalDate.now().plusDays(30); //Selected random due date
    }

    /**
     * Checks in the book
     */

    public void checkIn() {

        checkedOut = false;
        dueDate = null;
    }

    /** @Override toString method, this shows the Book object as a string.
     *
     * @return The Book object as a string
     */
    @Override
    public String toString() {
        return id + "," + title + "," + author+ "," + (checkedOut ? "Checked Out" : "Available");
    }

}

/**
 * Library class to manage a book collection.
 */

class Library {
    private List<Book> books;

    // Constructor to initialize the book list.
    public Library() {
        this.books = new ArrayList<>();

    }

    /**
     * Gets all the books in the library
     *
     * @return the list of all books in the library
     */

    public List<Book> getAllBooks() {
        return books;
    }

    /**
    * Adds a new book to the library
     *
     * @Param id The ID of the book
     * @param title The title of the book
     * @param author The author of the book
     */

    public void addBook(int id, String title, String author) {
        //Check if book with "unique" id already exists to avoid duplicates
        if (books.stream().anyMatch(book -> book.getId() == id)) {
            System.out.println("Book with ID " + id + " already exists.");
        } else {

            //If the book id is unique, create a new Book object and add it to library collection
            Book newBook = new Book(id, title, author);
            books.add(newBook);
        }
    }

    /** Method to remove a book from the library using its title
    *
    * @param title The title of the book to be removed
     */
    public void removeBookByTitle(String title) {
        books.removeIf(book -> book.getTitle().equals(title));
    }

    /**Method to display a list of all the books in the library
    *
    * @return A string representation of all the books in the library
     */
    public String listAllBooks() {
        StringBuilder result = new StringBuilder();
        for (Book book : books) {
            result.append(book.toString()).append("\n");
        }
        //Include current books in the collection
        result.append("\nCurrent Library:\n");
        for (Book book : books) {
            result.append(book.toString()).append("\n");
        }
        return result.toString();
    }

    /**
    * Method to remove books by barcode
    *
    * @param barcode is successfully removed
    * @return True if the book is successfully removed. false if not
     */
    public boolean removeBookByBarcode(int barcode) {
        for (Iterator<Book> iterator = books.iterator(); iterator.hasNext(); ) {
            Book book = iterator.next();
            if (book.getId() == barcode) {
                iterator.remove();
                return true; // Book found and removed
            }
        }
        return false; // Book not found
    }

    /**
    * Check out a book by its title
    *
    * @param title Title of the book to be checked out
     */

    public void checkOutBookByTitle(String title) {
        for (Book book : books) {
            if (book.getTitle().equals(title) && !book.isCheckedOut()) {
                book.checkOut();
                System.out.println("Book checked out successfully.");
                return;

            }

        }

        System.out.println("Book not available for checkout.");

    }

    /**
    * Checks in a book by its title
    *
    * @param The title of the book to be checked in
     */

    public void checkInBookByTitle(String title) {
        for (Book book : books) {
            if (book.getTitle().equals(title) && book.isCheckedOut()) {
                book.checkIn();
                System.out.println("Book checked in successfully.");
                return;
            }
        }
        System.out.println("Book not available for check-in.");

    }


    /**
     * Method to load books from a file into the library
     *
     * @param fileName The name of the file containing book information
     */
    public void loadBooksFromFile(String fileName) {
        try (Scanner scanner = new Scanner(new File(fileName))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);
                String title = parts[1];
                String author = parts[2];
                addBook(id, title, author);
            }
            JOptionPane.showMessageDialog(null, "File successfully entered.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "File not found: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

    }

    /**
    * If the fileName is the barcode
    *
    * @param fileName Method to save the current list of books to a file
    */
    public void saveBooksToFile(String fileName) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
            for (Book book : books) {
                writer.println(book);
            }
        } catch (IOException e) {
            System.out.println("Error, unable to write to file: " + e.getMessage());
        }
    }

    /**
     * Method to get list of books
     *
     * @return the list of books
     */
    public List<Book> getBooks() {
        return books;
    }

}

/**
* Represents the main class for the Library Management System
 */
public class LibraryManagementSystem {
    private Connection connection;

    /**
    * Constructs a LibraryManagementSystem object and establishes a database connection
     */

    public LibraryManagementSystem() {
        connectToDatabase();
    }

    /**
    * Connects to the database
     */

    public void connectToDatabase() {
        try {
            // Load the SQLite JDBC driver
            Class.forName("org.sqlite.JDBC");

            // Establish the connection
            String url = "jdbc:sqlite:C:/Users/AnEmb/IdeaProjects/LibraryManagementSystem/out/Library_Management_System.db";
            Connection connection = DriverManager.getConnection(url);

            // Do something with the connection (e.g., create tables, execute queries)
            // For example:
            Statement statement = connection.createStatement();
            statement.execute("CREATE TABLE IF NOT EXISTS books (id INTEGER PRIMARY KEY, title TEXT, author TEXT, checked_out BOOLEAN, due_date TEXT)");

            // Close the connection when done
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Handle any exceptions here
        }
    }
    /**
     * Adds a book to the database.
     *
     * @param book The book to be added.
     */
    public void addBookToDatabase(Book book) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO books (id, title, author, checked_out, due_date) VALUES (?, ?, ?, ?, ?)");
            preparedStatement.setInt(1, book.getId());
            preparedStatement.setString(2, book.getTitle());
            preparedStatement.setString(3, book.getAuthor());
            preparedStatement.setBoolean(4, book.isCheckedOut());
            preparedStatement.setString(5, book.getDueDate().toString());

            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle any exceptions here
        }
    }

    /**
    * Removed a book from the database
    *
    * @param id The ID of the book to be removed
     */

    public void removeBookFromDatabase(int id) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM books WHERE id = ?");
            preparedStatement.setInt(1, id);

            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle any exceptions here
        }
    }

    /**
    * The main method to run the LMS
    *
    * @param args The command-line arguments
     */

    public static void main(String[] args) {
        // Instantiate the Library class and load books from a file
        Library library = new Library();
        Scanner scanner = new Scanner(System.in);
        library.loadBooksFromFile("books.txt");

        // Establish database connection
        LibraryManagementSystem librarySystem = new LibraryManagementSystem();
        librarySystem.connectToDatabase();

        // Example: Add, remove, and list books.
        library.listAllBooks();

        // Save changes
        library.saveBooksToFile("books.txt");

        SwingUtilities.invokeLater(() -> {
            LibraryManagementSystemGUI gui = new LibraryManagementSystemGUI(library, scanner);
        });


        // Example: Add, remove, and list books.
        while (true) {System.out.println("\nLibrary Management System");
            System.out.println("1. Add a book");
            System.out.println("2. Remove a book by title");
            System.out.println("3. List all books");
            System.out.println("4. Remove a book by barcode");
            System.out.println("5. Check out a book by title");
            System.out.println("6. Check in a book by title");
            System.out.println("7. Exit");

            System.out.println("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter file name: ");
                    String fileName = scanner.nextLine();
                    library.loadBooksFromFile(fileName);
                    System.out.println("Books added from file.");
                    break;
                case 2:
                    System.out.print("Enter title to remove: ");
                    String titleToRemove = scanner.nextLine();
                    library.removeBookByTitle(titleToRemove);
                    System.out.println("Book removed by title. ");
                    System.out.println("Updated database:");
                    library.listAllBooks();
                    break;
                case 3:
                    System.out.println("Printing the database to screen...");
                    library.listAllBooks();
                    break;
                case 4:
                    System.out.print("Enter barcode to remove: ");
                    int barcodeToRemove = scanner.nextInt();
                    library.removeBookByBarcode(barcodeToRemove);
                    System.out.println("Book removed by barcode.");
                    System.out.println("Updated database: ");
                    library.listAllBooks();
                    break;


                case 5:
                    System.out.print("Enter title to check out: ");
                    String titleToCheckOut = scanner.nextLine();
                    library.checkOutBookByTitle(titleToCheckOut);
                    System.out.println("Book checked out.");
                    System.out.println("Updated database: ");
                    library.listAllBooks();
                    break;
                case 6:
                    System.out.print("Enter title to check in: ");
                    String titleToCheckIn = scanner.nextLine();
                    library.checkInBookByTitle(titleToCheckIn);
                    System.out.println("Book checked in.");
                    System.out.println("Updated database: ");
                    library.listAllBooks();
                    break;
                case 7:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again. ");

            }
        }
    }
}
